﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;

namespace Final_Project__Working_
{//Written by Andrew Mazer. Creates a workoutplan in an excel spreadsheet by using user input. button on this form leads to another form.  
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // creates objects and gives them there type to be used later
        string backSquat;
        string deadlift;
        string benchPress;
        int numBSmax;
        int numDLmax;
        int numBPmax;
        private void button1_Click(object sender, EventArgs e)
        {
            backSquat = textBox2.Text; //takes user input of back squat max and stores it in backSquat
            numBSmax = Int32.Parse(backSquat); // converts user input from string to integer 
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            deadlift = textBox3.Text; //takes user input of deadlift max and stores it in deadlift
            numDLmax = Int32.Parse(deadlift); // converts user input from string to integer 
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
              benchPress = textBox4.Text; //takes user input of bench press max and stores it in benchPress
            numBPmax = Int32.Parse(benchPress);  // converts user input from string to integer                  
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            //creates an excel workbook, source code which this is based off to work with excel file: http://csharp.net-informations.com/excel/csharp-create-excel.htm
            Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;


            object misValue = System.Reflection.Missing.Value;

            xlWorkBook = xlApp.Workbooks.Add(misValue);
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);


            //edits cells in excel file
            xlWorkSheet.Cells[1, 1] = "Week 1";
            xlWorkSheet.Cells[1, 2] = "M";
            xlWorkSheet.Cells[2, 2] = "Back Squat";
            xlWorkSheet.Cells[3, 2] = "Stiff Leg Deadlift";
            xlWorkSheet.Cells[4, 2] = "DB Snatch";
            xlWorkSheet.Cells[5, 2] = "Box Jumps";
            xlWorkSheet.Cells[2, 3] = "3x3 @" + (numBSmax * 0.70);
            xlWorkSheet.Cells[3, 3] = "5x6";
            xlWorkSheet.Cells[4, 3] = "5x8";
            xlWorkSheet.Cells[5, 3] = "5x8";
            xlWorkSheet.Cells[6, 2] = "T";
            xlWorkSheet.Cells[7, 2] = "Bench Press";
            xlWorkSheet.Cells[8, 2] = "Shoulder Press";
            xlWorkSheet.Cells[9, 2] = "Arnold Press";
            xlWorkSheet.Cells[10, 2] = "Any Tricep Excercise";
            xlWorkSheet.Cells[7, 3] = "4x4 @" + (numBPmax * 0.80) + " " + "2x2 @" + (numBPmax * 0.90);
            xlWorkSheet.Cells[8, 3] = "5x6";
            xlWorkSheet.Cells[9, 3] = "5x8";
            xlWorkSheet.Cells[10, 3] = "5x8";
            xlWorkSheet.Cells[11, 2] = "W";
            xlWorkSheet.Cells[12, 2] = "Deadlift";
            xlWorkSheet.Cells[13, 2] = "Barbell Back Rows";
            xlWorkSheet.Cells[14, 2] = "Lat Pull Downs";
            xlWorkSheet.Cells[15, 2] = "Pull Overs";
            xlWorkSheet.Cells[16, 2] = "Any Bicep Excercise";
            xlWorkSheet.Cells[12, 3] = "5x3 @" + (numDLmax * 0.85);
            xlWorkSheet.Cells[13, 3] = "5x6";
            xlWorkSheet.Cells[14, 3] = "5x8";
            xlWorkSheet.Cells[15, 3] = "5x5";
            xlWorkSheet.Cells[16, 3] = "5x8";
            xlWorkSheet.Cells[17, 2] = "Th";
            xlWorkSheet.Cells[18, 2] = "Back Squat";
            xlWorkSheet.Cells[19, 2] = "Stiff Leg Deadlift";
            xlWorkSheet.Cells[20, 2] = "Goblet Squat";
            xlWorkSheet.Cells[21, 2] = "Lunges";
            xlWorkSheet.Cells[18, 3] = "3x5 @" + (numBSmax * 0.75) + " " + "3x2 @" + (numBSmax * 0.88);
            xlWorkSheet.Cells[19, 3] = "5x6";
            xlWorkSheet.Cells[20, 3] = "5x8";
            xlWorkSheet.Cells[21, 3] = "5x8";
            xlWorkSheet.Cells[22, 2] = "F";
            xlWorkSheet.Cells[23, 2] = "Bench Press";
            xlWorkSheet.Cells[24, 2] = "Military Press";
            xlWorkSheet.Cells[25, 2] = "Front Raises";
            xlWorkSheet.Cells[26, 2] = "Any Tricep Excercise";
            xlWorkSheet.Cells[23, 3] = "3x3 @" + (numBPmax * 0.80) + " " + "2x2 @" + (numBPmax * 0.90) + " " + "1x1 @" + (numBPmax * 0.95);
            xlWorkSheet.Cells[24, 3] = "5x6";
            xlWorkSheet.Cells[25, 3] = "5x8";
            xlWorkSheet.Cells[26, 3] = "5x8";

            xlWorkSheet.Cells[28, 1] = "Week 2";
            xlWorkSheet.Cells[28, 2] = "M";
            xlWorkSheet.Cells[29, 2] = "Back Squat";
            xlWorkSheet.Cells[30, 2] = "Stiff Leg Deadlift";
            xlWorkSheet.Cells[31, 2] = "Front Squat";
            xlWorkSheet.Cells[32, 2] = "Leg Press";
            xlWorkSheet.Cells[29, 3] = "3x3 @" + (numBSmax * 0.80);
            xlWorkSheet.Cells[30, 3] = "5x6";
            xlWorkSheet.Cells[31, 3] = "5x8";
            xlWorkSheet.Cells[32, 3] = "5x8";
            xlWorkSheet.Cells[33, 2] = "T";
            xlWorkSheet.Cells[34, 2] = "Bench Press";
            xlWorkSheet.Cells[35, 2] = "Shoulder Press";
            xlWorkSheet.Cells[36, 2] = "Arnold Press";
            xlWorkSheet.Cells[37, 2] = "Any Tricep Excercise";
            xlWorkSheet.Cells[34, 3] = "5x3 @" + (numBPmax * 0.83) + " " + "3x2 @" + (numBPmax * 0.94);
            xlWorkSheet.Cells[35, 3] = "5x6";
            xlWorkSheet.Cells[36, 3] = "5x8";
            xlWorkSheet.Cells[37, 3] = "5x8";
            xlWorkSheet.Cells[38, 2] = "W";
            xlWorkSheet.Cells[39, 2] = "Deadlift";
            xlWorkSheet.Cells[40, 2] = "Barbell Back Rows";
            xlWorkSheet.Cells[41, 2] = "Lat Pull Downs";
            xlWorkSheet.Cells[42, 2] = "Pull Overs";
            xlWorkSheet.Cells[43, 2] = "Any Bicep Excercise";
            xlWorkSheet.Cells[39, 3] = "5x5 @" + (numDLmax * 0.75);
            xlWorkSheet.Cells[40, 3] = "5x6";
            xlWorkSheet.Cells[41, 3] = "5x8";
            xlWorkSheet.Cells[42, 3] = "5x5";
            xlWorkSheet.Cells[43, 3] = "5x8";
            xlWorkSheet.Cells[44, 2] = "Th";
            xlWorkSheet.Cells[45, 2] = "Back Squat";
            xlWorkSheet.Cells[46, 2] = "Stiff Leg Deadlift";
            xlWorkSheet.Cells[47, 2] = "Goblet Squat";
            xlWorkSheet.Cells[48, 2] = "Box Jumps";
            xlWorkSheet.Cells[45, 3] = "6x3 @" + (numBSmax * 0.75) + " " + "3x1 @" + (numBSmax * 0.94);
            xlWorkSheet.Cells[46, 3] = "5x6";
            xlWorkSheet.Cells[47, 3] = "5x8";
            xlWorkSheet.Cells[48, 3] = "5x8";
            xlWorkSheet.Cells[49, 2] = "F";
            xlWorkSheet.Cells[50, 2] = "Bench Press";
            xlWorkSheet.Cells[51, 2] = "Military Press";
            xlWorkSheet.Cells[52, 2] = "Front Raises";
            xlWorkSheet.Cells[53, 2] = "Any Tricep Excercise";
            xlWorkSheet.Cells[50, 3] = "3x3 @" + (numBPmax * 0.80) + " " + "2x2 @" + (numBPmax * 0.90) + " " + "1x1 @" + (numBPmax * 0.95);
            xlWorkSheet.Cells[51, 3] = "5x6";
            xlWorkSheet.Cells[52, 3] = "5x8";
            xlWorkSheet.Cells[53, 3] = "5x8";












            // entered text automatically fits into columns
            xlWorkSheet.Columns.AutoFit();


            //saves the file and opens it
            xlWorkBook.SaveAs("WeightLiftingProgram", Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            xlApp.Visible = true;

            Marshal.ReleaseComObject(xlWorkSheet);
            Marshal.ReleaseComObject(xlWorkBook);
            Marshal.ReleaseComObject(xlApp);

        }

        private void button4_Click(object sender, EventArgs e)
        {
            // opens second form
            Form2 f2 = new Form2();
            f2.ShowDialog();
        }
    }
}
