﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Project__Working_
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        // classfies objects
        string input;
        string input2;
        string input3;
        int squatWeight;
        int deadWeight;
        int benchWeight;
        string lift;
        private void button1_Click(object sender, EventArgs e)
        {
            // user input of whatever lift that is decided sets a value to "lift"
            input = textBox2.Text;
            if (input == "back squat")
            {
                lift = "back squat";
            }
            if (input == "deadlift")
            {
                lift = "deadlift";
            }
            if (input == "bench press")
            {
                lift = "bench press";
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
           
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            // uses switch to take user input to correctly calculate one rep max based on chosen lift
            switch (lift)
            {
                case "bench press":
                    input2 = textBox3.Text;
                    input3 = textBox4.Text;
                    benchWeight = Int32.Parse(input3);
                    //when user selects a 'number' the weight inputted multiplies into the correct number for the one rep max formula.
                    if (input2 == "one")
                    {
                        double max = benchWeight * 1.0;
                        string result = max.ToString();
                        textBox5.Text = result;
                        textBox5.Focus();

                    }
                    if (input2 == "two")
                    {
                        double max = benchWeight * 1.035;
                        string result = max.ToString();
                        textBox5.Text = result;
                        textBox5.Focus();
                    }
                    if (input2 == "three")
                    {
                        double max = benchWeight * 1.08;
                        string result = max.ToString();
                        textBox5.Text = result;
                        textBox5.Focus();
                    }
                    if (input2 == "four")
                    {
                        double max = benchWeight * 1.115;
                        string result = max.ToString();
                        textBox5.Text = result;
                        textBox5.Focus();
                    }
                    if (input2 == "five")
                    {
                        double max = benchWeight * 1.15;
                        string result = max.ToString();
                        textBox5.Text = result;
                        textBox5.Focus();
                    }
                    if (input2 == "six")
                    {
                        double max = benchWeight * 1.18;
                        string result = max.ToString();
                        textBox5.Text = result;
                        textBox5.Focus();
                    }
                    if (input2 == "seven")
                    {
                        double max = benchWeight * 1.22;
                        string result = max.ToString();
                        textBox5.Text = result;
                        textBox5.Focus();
                    }
                    if (input2 == "eight")
                    {
                        double max = benchWeight * 1.255;
                        string result = max.ToString();
                        textBox5.Text = result;
                        textBox5.Focus();
                    }
                    if (input2 == "nine")
                    {
                        double max = benchWeight * 1.29;
                        string result = max.ToString();
                        textBox5.Text = result;
                        textBox5.Focus();
                    }
                    if (input2 == "ten")
                    {
                        double max = benchWeight * 1.325;
                        string result = max.ToString();
                        textBox5.Text = result;
                        textBox5.Focus();
                    }


                    break;

                case "deadlift":
                    input2 = textBox3.Text;
                    input3 = textBox4.Text;
                    deadWeight = Int32.Parse(input3);
                    if (input2 == "one")
                    {
                        double max = deadWeight * 1.0;
                        string result = max.ToString();
                        textBox5.Text = result;
                        textBox5.Focus();

                    }
                    if (input2 == "two")
                    {
                        double max = deadWeight * 1.065;
                        string result = max.ToString();
                        textBox5.Text = result;
                        textBox5.Focus();
                    }
                    if (input2 == "three")
                    {
                        double max = deadWeight * 1.13;
                        string result = max.ToString();
                        textBox5.Text = result;
                        textBox5.Focus();
                    }
                    if (input2 == "four")
                    {
                        double max = deadWeight * 1.147;
                        string result = max.ToString();
                        textBox5.Text = result;
                        textBox5.Focus();
                    }
                    if (input2 == "five")
                    {
                        double max = deadWeight * 1.164;
                        string result = max.ToString();
                        textBox5.Text = result;
                        textBox5.Focus();
                    }
                    if (input2 == "six")
                    {
                        double max = deadWeight * 1.181;
                        string result = max.ToString();
                        textBox5.Text = result;
                        textBox5.Focus();
                    }
                    if (input2 == "seven")
                    {
                        double max = deadWeight * 1.198;
                        string result = max.ToString();
                        textBox5.Text = result;
                        textBox5.Focus();
                    }
                    if (input2 == "eight")
                    {
                        double max = deadWeight * 1.232;
                        string result = max.ToString();
                        textBox5.Text = result;
                        textBox5.Focus();
                    }
                    if (input2 == "nine")
                    {
                        double max = deadWeight * 1.232;
                        string result = max.ToString();
                        textBox5.Text = result;
                        textBox5.Focus();
                    }
                    if (input2 == "ten")
                    {
                        double max = deadWeight * 1.24;
                        string result = max.ToString();
                        textBox5.Text = result;
                        textBox5.Focus();
                    }

                    break;
                case "back squat":
                    input2 = textBox3.Text;
                    input3 = textBox4.Text;
                    squatWeight = Int32.Parse(input3);
                    if (input2 == "one")
                    {
                        double max = squatWeight * 1.0;
                        string result = max.ToString();
                        textBox5.Text = result;
                        textBox5.Focus();

                    }
                    if (input2 == "two")
                    {
                        double max = squatWeight * 1.0475;
                        string result = max.ToString();
                        textBox5.Text = result;
                        textBox5.Focus();
                    }
                    if (input2 == "three")
                    {
                        double max = squatWeight * 1.13;
                        string result = max.ToString();
                        textBox5.Text = result;
                        textBox5.Focus();
                    }
                    if (input2 == "four")
                    {
                        double max = squatWeight * 1.1575;
                        string result = max.ToString();
                        textBox5.Text = result;
                        textBox5.Focus();
                    }
                    if (input2 == "five")
                    {
                        double max = squatWeight * 1.2;
                        string result = max.ToString();
                        textBox5.Text = result;
                        textBox5.Focus();
                    }
                    if (input2 == "six")
                    {
                        double max = squatWeight * 1.242;
                        string result = max.ToString();
                        textBox5.Text = result;
                        textBox5.Focus();
                    }
                    if (input2 == "seven")
                    {
                        double max = squatWeight * 1.284;
                        string result = max.ToString();
                        textBox5.Text = result;
                        textBox5.Focus();
                    }
                    if (input2 == "eight")
                    {
                        double max = squatWeight * 1.326;
                        string result = max.ToString();
                        textBox5.Text = result;
                        textBox5.Focus();
                    }
                    if (input2 == "nine")
                    {
                        double max = squatWeight * 1.368;
                        string result = max.ToString();
                        textBox5.Text = result;
                        textBox5.Focus();
                    }
                    if (input2 == "ten")
                    {
                        double max = squatWeight * 1.41;
                        string result = max.ToString();
                        textBox5.Text = result;
                        textBox5.Focus();
                    }

                    break;
            }
            }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
